# Learning Progress Tracker — Track B (React + Node.js/Express)

Capstone implementation of the shared project brief using **React (Vite)** for the frontend and
**Node.js + Express** for the REST API, with **SQLite** (`better-sqlite3`) as the relational database.

## Features

- Coordinator: add candidates (one-time temporary credentials), reset credentials, create/edit activities,
  assign training (duplicates rejected), view cohort totals and per-learner progress.
- Candidate: sign in, replace the temporary password on first login, see **only** their own training,
  update their own status, log out.
- Server-side role and ownership checks on every route (`401` / `403` / `404` / `409` / `400`).

## Security design

| Requirement | Implementation |
|---|---|
| Hashed passwords | `bcryptjs` salted hashes only; never stored, logged or returned in plaintext |
| Sessions | `express-session` + SQLite store; `HttpOnly`, `SameSite=Lax`, `Secure` when `COOKIE_SECURE=true`; 2 h idle expiry; session id regenerated on login and password change |
| CSRF | Synchronizer token kept in the server session, required in `X-CSRF-Token` on every state-changing request |
| Rate limiting | `express-rate-limit` on login (10 attempts / 15 min / IP) |
| Generic errors | Login failures always return `Invalid email or password.` |
| Temporary credentials | Random 14-char password, expires after 24 h, shown once with `Cache-Control: no-store` |
| First login | A temporary session can only change the password or log out (`403` elsewhere) |
| Reset | Coordinator reset issues new credentials, deletes the candidate's sessions, restores first-login flow |
| Headers | `helmet` |
| No browser storage | The CSRF token and one-time credentials live in React memory only |

Use HTTPS outside localhost (set `COOKIE_SECURE=true` and `TRUST_PROXY=true` behind a TLS proxy).

## Prerequisites

Node.js 20+ and npm.

## Setup

```bash
# 1. Install dependencies
npm run install:all

# 2. Configure the server
cp server/.env.example server/.env
#    Edit server/.env:
#      SESSION_SECRET      -> long random string
#      COORDINATOR_EMAIL / COORDINATOR_PASSWORD (min 12 chars) -> first coordinator

# 3. Create the database, the coordinator, and fictional sample data
npm run seed          # or: npm run setup:db   (coordinator only, no sample data)
#    Afterwards remove COORDINATOR_PASSWORD from server/.env.
```

The seed adds 3 fictional learners, 4 activities and 8 assignments. Seeded candidates have an
expired random password (nothing is printed). Sign in as the coordinator and use **Reset credentials**
on the Candidates page to hand over a login — this also demonstrates the reset flow.

## Run (development)

```bash
npm run dev:server    # API on http://localhost:4000
npm run dev:client    # UI  on http://localhost:5173 (proxies /api to the API)
```

Open http://localhost:5173.

## Run (single server)

```bash
npm run build         # builds client/dist
NODE_ENV=production npm start   # Express serves the API and the built UI on :4000
```

## Tests

```bash
npm test
```

Covers: required-field and positive-hours validation, duplicate-assignment prevention, the primary
workflow (create candidate → handover → first login → password change → training → progress → summary),
duplicate emails, invalid/expired credentials, first-login enforcement, logout, coordinator reset,
coordinator-only actions, cross-candidate read/update denial, CSRF, and login rate limiting.
Middleware unit tests mock the database/session dependencies.

## Environment variables (`server/.env`)

| Variable | Purpose |
|---|---|
| `PORT` | API port (default 4000) |
| `SESSION_SECRET` | Session signing secret (required in production) |
| `DATABASE_PATH` | SQLite file (default `./data/tracker.sqlite`) |
| `COOKIE_SECURE` / `TRUST_PROXY` | Enable behind HTTPS / reverse proxy |
| `COORDINATOR_EMAIL` / `COORDINATOR_PASSWORD` | Used only by `db:setup` / `db:seed` |

## API

All routes are under `/api/v1`. Coordinator-only: `activities`, `learners`, `cohort-summary`,
`POST assignments`. Candidate-only: `PATCH assignments/:id/status` (own assignments),
`GET me/assignments`. Auth: `GET auth/csrf`, `GET auth/me`, `POST auth/login`,
`POST auth/change-password`, `POST auth/logout`. Errors use `{ "message": "..." }`.

## Data model

`accounts` (email unique/normalised, password_hash, role, must_change_password, temp_password_expires_at) →
`learners` (name, cohort, account_id) → `assignments` (learner_id, activity_id, status; `UNIQUE(learner_id, activity_id)`)
← `activities` (title, topic, planned_hours > 0). `sessions` backs the session store.

## Project layout

```
server/  src/{app,server,setup,db,accounts,passwords,validation,middleware,sessionStore}.js
         src/routes/  test/
client/  src/{App,AuthContext,api,useLoad}.* src/pages/ src/components/
```
