import { useCallback, useEffect, useState } from 'react';
import { useAuth } from './AuthContext.jsx';

/** Loads data with loading + error + retry states; a 401 sends the person back to sign in. */
export function useLoad(loader, deps = []) {
  const { expireSession } = useAuth();
  const [state, setState] = useState({ data: null, loading: true, error: null });

  const load = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      setState({ data: await loader(), loading: false, error: null });
    } catch (err) {
      if (err.status === 401) return expireSession();
      setState({ data: null, loading: false, error: err.message });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    load();
  }, [load]);

  return { ...state, reload: load, setData: (data) => setState((s) => ({ ...s, data })) };
}
