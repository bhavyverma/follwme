import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, loadCsrf } from './api.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        await loadCsrf();
        setUser(await api.get('/auth/me'));
      } catch {
        setUser(null); // 401 or offline: show the login page
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const login = useCallback(async (email, password) => {
    const { csrfToken, ...profile } = await api.post('/auth/login', { email, password });
    api.setCsrf(csrfToken);
    setUser(profile);
    return profile;
  }, []);

  const changePassword = useCallback(async (currentPassword, newPassword) => {
    await api.post('/auth/change-password', { currentPassword, newPassword });
    setUser((u) => ({ ...u, mustChangePassword: false }));
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } finally {
      setUser(null);
      await loadCsrf().catch(() => {});
    }
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, logout, changePassword, expireSession: () => { setUser(null); loadCsrf().catch(() => {}); } }),
    [user, loading, login, logout, changePassword]
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
