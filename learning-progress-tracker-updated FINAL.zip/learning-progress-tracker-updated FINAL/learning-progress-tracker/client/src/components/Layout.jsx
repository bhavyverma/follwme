import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const showNav = user && !user.mustChangePassword && user.role === 'Coordinator';

  return (
    <>
      <a className="skip" href="#main">Skip to main content</a>
      <header className="topbar">
        <p className="brand">Learning Progress Tracker</p>
        {showNav && (
          <nav aria-label="Main">
            <NavLink to="/dashboard">Dashboard</NavLink>
            <NavLink to="/activities">Activities</NavLink>
            <NavLink to="/candidates">Candidates</NavLink>
          </nav>
        )}
        {user && (
          <button
            type="button"
            className="btn quiet"
            onClick={async () => {
              await logout();
              navigate('/login');
            }}
          >
            Log out
          </button>
        )}
      </header>
      <main id="main" tabIndex={-1}>{children}</main>
    </>
  );
}
