export const Loading = ({ label = 'Loading…' }) => (
  <p className="loading" role="status">{label}</p>
);

export const ErrorMessage = ({ message, onRetry }) => (
  <div className="notice error" role="alert">
    <p>{message}</p>
    {onRetry && (
      <button type="button" className="btn" onClick={onRetry}>Try again</button>
    )}
  </div>
);

export const Notice = ({ type = 'success', children }) => (
  <p className={`notice ${type}`} role={type === 'error' ? 'alert' : 'status'}>{children}</p>
);

export const Empty = ({ children }) => <p className="empty">{children}</p>;

const FILLED = { 'Not Started': 0, 'In Progress': 2, Completed: 3 };

/** Status is shown as text and as a three-segment strip, never by colour alone. */
export function StatusBadge({ status }) {
  const filled = FILLED[status] ?? 0;
  const cls = status === 'Completed' ? 'done' : status === 'In Progress' ? 'doing' : 'todo';
  return (
    <span className={`status ${cls}`}>
      <span className="strip" aria-hidden="true">
        {[0, 1, 2].map((i) => (
          <i key={i} className={i < filled ? 'on' : ''} />
        ))}
      </span>
      {status}
    </span>
  );
}
