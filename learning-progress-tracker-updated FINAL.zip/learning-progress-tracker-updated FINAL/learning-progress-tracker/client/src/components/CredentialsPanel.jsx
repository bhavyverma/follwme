export default function CredentialsPanel({ title, credentials, onDismiss }) {
  const expires = new Date(credentials.expiresAt).toLocaleString();
  return (
    <section className="panel credentials" aria-labelledby="cred-title">
      <h2 id="cred-title">{title}</h2>
      <p>
        Shown once. Give these to the candidate privately — they can’t be retrieved later.
        The temporary password expires {expires} and must be replaced at first sign-in.
      </p>
      <dl className="kv">
        <dt>Username</dt>
        <dd><code>{credentials.username}</code></dd>
        <dt>Temporary password</dt>
        <dd><code>{credentials.temporaryPassword}</code></dd>
      </dl>
      <button type="button" className="btn" onClick={onDismiss}>I’ve handed these over</button>
    </section>
  );
}
