import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import { Notice } from '../components/Feedback.jsx';
import { homeFor } from '../routes.js';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const profile = await login(email, password);
      navigate(homeFor(profile), { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setPassword(''); // never keep credentials after submission
      setBusy(false);
    }
  }

  return (
    <section className="auth-card">
      <h1>Sign in</h1>
      <p className="hint">Candidates: use the username and temporary password your coordinator gave you.</p>
      <form onSubmit={submit}>
        <label htmlFor="email">Email</label>
        <input id="email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <label htmlFor="password">Password</label>
        <input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <Notice type="error">{error}</Notice>}
        <button className="btn primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </section>
  );
}
