import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';
import { Notice } from '../components/Feedback.jsx';
import { homeFor } from '../routes.js';

export default function ChangePassword() {
  const { user, changePassword } = useAuth();
  const navigate = useNavigate();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError('');
    if (next.length < 10) return setError('New password must be at least 10 characters.');
    if (next !== confirm) return setError('The new passwords do not match.');
    setBusy(true);
    try {
      await changePassword(current, next);
      navigate(homeFor({ ...user, mustChangePassword: false }), { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setCurrent('');
      setNext('');
      setConfirm('');
      setBusy(false);
    }
  }

  return (
    <section className="auth-card">
      <h1>{user?.mustChangePassword ? 'Choose a new password' : 'Change password'}</h1>
      {user?.mustChangePassword && (
        <p className="hint">Your temporary password must be replaced before you can continue.</p>
      )}
      <form onSubmit={submit}>
        <label htmlFor="current">Current (temporary) password</label>
        <input id="current" type="password" autoComplete="current-password" required value={current} onChange={(e) => setCurrent(e.target.value)} />
        <label htmlFor="new">New password</label>
        <input id="new" type="password" autoComplete="new-password" required minLength={10} aria-describedby="pw-hint" value={next} onChange={(e) => setNext(e.target.value)} />
        <p id="pw-hint" className="hint">At least 10 characters.</p>
        <label htmlFor="confirm">Confirm new password</label>
        <input id="confirm" type="password" autoComplete="new-password" required value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        {error && <Notice type="error">{error}</Notice>}
        <button className="btn primary" disabled={busy}>{busy ? 'Saving…' : 'Save new password'}</button>
      </form>
    </section>
  );
}
