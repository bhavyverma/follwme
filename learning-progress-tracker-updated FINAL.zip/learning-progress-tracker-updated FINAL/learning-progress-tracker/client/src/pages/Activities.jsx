import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { Empty, ErrorMessage, Loading, Notice } from '../components/Feedback.jsx';
import { useLoad } from '../useLoad.js';

const blank = { title: '', topic: '', plannedHours: '' };

function validate(f) {
  const errors = {};
  if (!f.title.trim()) errors.title = 'Title is required.';
  if (!f.topic.trim()) errors.topic = 'Topic is required.';
  const hours = Number(f.plannedHours);
  if (f.plannedHours === '' || !Number.isFinite(hours) || hours <= 0) {
    errors.plannedHours = 'Planned hours must be greater than zero.';
  }
  return errors;
}

export default function Activities() {
  const { expireSession } = useAuth();
  const { data, loading, error, reload } = useLoad(() => api.get('/activities'), []);
  const [params, setParams] = useSearchParams();
  const [form, setForm] = useState(null); // null = closed; otherwise { id?, ...fields }
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState(null);

  // Open the form from ?new=1 or ?edit=ID (links from the dashboard).
  useEffect(() => {
    if (params.get('new')) setForm({ ...blank });
    const editId = Number(params.get('edit'));
    if (editId && data) {
      const a = data.find((x) => x.id === editId);
      if (a) setForm({ id: a.id, title: a.title, topic: a.topic, plannedHours: String(a.plannedHours) });
    }
  }, [params, data]);

  const close = () => {
    setForm(null);
    setErrors({});
    if (params.size) setParams({}, { replace: true });
  };

  async function save(e) {
    e.preventDefault();
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length) return;
    const payload = { title: form.title.trim(), topic: form.topic.trim(), plannedHours: Number(form.plannedHours) };
    try {
      if (form.id) await api.put(`/activities/${form.id}`, payload);
      else await api.post('/activities', payload);
      setMessage({ type: 'success', text: form.id ? 'Activity updated.' : 'Activity created.' });
      close();
      reload();
    } catch (err) {
      if (err.status === 401) return expireSession();
      // Keep the entered values so nothing is lost.
      setMessage({ type: 'error', text: `Could not save the activity. ${err.message}` });
    }
  }

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  const field = (key, label, props = {}) => (
    <div className="field">
      <label htmlFor={`act-${key}`}>{label}</label>
      <input id={`act-${key}`} value={form[key]} onChange={set(key)}
        aria-invalid={Boolean(errors[key])} aria-describedby={errors[key] ? `act-${key}-err` : undefined} {...props} />
      {errors[key] && <p id={`act-${key}-err`} className="field-error">{errors[key]}</p>}
    </div>
  );

  return (
    <>
      <div className="page-head">
        <h1>Activities</h1>
        {!form && <button type="button" className="btn primary" onClick={() => setForm({ ...blank })}>+ Add activity</button>}
      </div>

      {message && <Notice type={message.type}>{message.text}</Notice>}

      {form && (
        <form className="panel" onSubmit={save} noValidate aria-labelledby="form-h">
          <h2 id="form-h">{form.id ? 'Edit activity' : 'New activity'}</h2>
          {field('title', 'Title')}
          {field('topic', 'Topic')}
          {field('plannedHours', 'Planned hours', { type: 'number', step: '0.5', min: '0', inputMode: 'decimal' })}
          <div className="actions">
            <button className="btn primary">Save activity</button>
            <button type="button" className="btn" onClick={close}>Cancel</button>
          </div>
        </form>
      )}

      {loading && !data && <Loading label="Loading activities…" />}
      {error && <ErrorMessage message={error} onRetry={reload} />}
      {data?.length === 0 && <Empty>No activities yet. Add one to start building the curriculum.</Empty>}
      {data?.length > 0 && (
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">Title</th><th scope="col">Topic</th><th scope="col">Planned hours</th><th scope="col"><span className="sr">Actions</span></th></tr></thead>
            <tbody>
              {data.map((a) => (
                <tr key={a.id}>
                  <th scope="row">{a.title}</th>
                  <td>{a.topic}</td>
                  <td>{a.plannedHours}</td>
                  <td><button type="button" className="btn" aria-label={`Edit ${a.title}`}
                    onClick={() => { setMessage(null); setForm({ id: a.id, title: a.title, topic: a.topic, plannedHours: String(a.plannedHours) }); }}>Edit</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
