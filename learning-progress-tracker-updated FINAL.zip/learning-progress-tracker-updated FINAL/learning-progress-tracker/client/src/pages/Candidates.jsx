import { useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import CredentialsPanel from '../components/CredentialsPanel.jsx';
import { Empty, ErrorMessage, Loading, Notice } from '../components/Feedback.jsx';
import { useLoad } from '../useLoad.js';

const blank = { name: '', email: '', cohort: '' };

export default function Candidates() {
  const { expireSession } = useAuth();
  const { data, loading, error, reload } = useLoad(() => api.get('/learners'), []);
  const [form, setForm] = useState(null);
  const [errors, setErrors] = useState({});
  const [issued, setIssued] = useState(null); // one-time credentials, held in memory only
  const [message, setMessage] = useState(null);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  async function create(e) {
    e.preventDefault();
    setMessage(null);
    const found = {};
    if (!form.name.trim()) found.name = 'Name is required.';
    if (!form.email.trim()) found.email = 'Email is required.';
    if (!form.cohort.trim()) found.cohort = 'Cohort is required.';
    setErrors(found);
    if (Object.keys(found).length) return;
    try {
      const created = await api.post('/learners', form);
      setIssued({ title: `Account created for ${created.name}`, credentials: created.credentials });
      setForm(null);
      reload();
    } catch (err) {
      if (err.status === 401) return expireSession();
      if (err.status === 409 || err.status === 400) {
        const key = /email/i.test(err.message) ? 'email' : /name/i.test(err.message) ? 'name' : /cohort/i.test(err.message) ? 'cohort' : null;
        if (key) return setErrors({ [key]: err.message });
      }
      setMessage({ type: 'error', text: `Could not create the account. ${err.message}` });
    }
  }

  async function reset(learner) {
    if (!window.confirm(`Issue new temporary credentials for ${learner.name}? Their current password and sessions stop working.`)) return;
    setMessage(null);
    try {
      const result = await api.post(`/learners/${learner.id}/reset-password`);
      setIssued({ title: `New temporary password for ${learner.name}`, credentials: result.credentials });
    } catch (err) {
      if (err.status === 401) return expireSession();
      setMessage({ type: 'error', text: `Could not reset credentials. ${err.message}` });
    }
  }

  return (
    <>
      <div className="page-head">
        <h1>Candidates</h1>
        {!form && <button type="button" className="btn primary" onClick={() => { setIssued(null); setErrors({}); setForm({ ...blank }); }}>Add candidate</button>}
      </div>

      {message && <Notice type={message.type}>{message.text}</Notice>}
      {issued && <CredentialsPanel title={issued.title} credentials={issued.credentials} onDismiss={() => setIssued(null)} />}

      {form && (
        <form className="panel" onSubmit={create} noValidate aria-labelledby="cand-h">
          <h2 id="cand-h">New candidate</h2>
          {[['name', 'Name', 'text'], ['email', 'Email', 'email'], ['cohort', 'Cohort', 'text']].map(([key, label, type]) => (
            <div className="field" key={key}>
              <label htmlFor={`cand-${key}`}>{label}</label>
              <input id={`cand-${key}`} type={type} value={form[key]} onChange={set(key)} autoComplete="off"
                aria-invalid={Boolean(errors[key])} aria-describedby={errors[key] ? `cand-${key}-err` : undefined} />
              {errors[key] && <p id={`cand-${key}-err`} className="field-error">{errors[key]}</p>}
            </div>
          ))}
          <div className="actions">
            <button className="btn primary">Create account</button>
            <button type="button" className="btn" onClick={() => setForm(null)}>Cancel</button>
          </div>
        </form>
      )}

      {loading && !data && <Loading label="Loading candidates…" />}
      {error && <ErrorMessage message={error} onRetry={reload} />}
      {data?.length === 0 && <Empty>No candidates yet. Add one to create their login.</Empty>}
      {data?.length > 0 && (
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">Name</th><th scope="col">Email</th><th scope="col">Cohort</th><th scope="col">Completed</th><th scope="col"><span className="sr">Actions</span></th></tr></thead>
            <tbody>
              {data.map((l) => (
                <tr key={l.id}>
                  <th scope="row">{l.name}</th>
                  <td>{l.email}</td>
                  <td>{l.cohort}</td>
                  <td>{l.completedCount} of {l.assignmentCount}</td>
                  <td><button type="button" className="btn" onClick={() => reset(l)} aria-label={`Reset credentials for ${l.name}`}>Reset credentials</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
