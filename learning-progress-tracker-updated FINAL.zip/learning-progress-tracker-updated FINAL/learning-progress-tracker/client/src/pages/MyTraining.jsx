import { useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { Empty, ErrorMessage, Loading, Notice, StatusBadge } from '../components/Feedback.jsx';
import { useLoad } from '../useLoad.js';

const STATUSES = ['Not Started', 'In Progress', 'Completed'];

export default function MyTraining() {
  const { user, expireSession } = useAuth();
  const { data, loading, error, reload, setData } = useLoad(() => api.get('/me/assignments'), []);
  const [message, setMessage] = useState(null);

  async function updateStatus(assignment, status) {
    setMessage(null);
    try {
      const updated = await api.patch(`/assignments/${assignment.id}/status`, { status });
      setData(data.map((a) => (a.id === updated.id ? updated : a)));
      setMessage({ type: 'success', text: `${assignment.activity.title} is now “${status}”.` });
    } catch (err) {
      if (err.status === 401) return expireSession();
      setMessage({ type: 'error', text: `Could not save your progress. ${err.message}` });
    }
  }

  return (
    <>
      <div className="page-head">
        <h1>My training</h1>
        <p className="who">Signed in: <strong>{user.name}</strong>{user.cohort && `, ${user.cohort}`}</p>
      </div>

      {message && <Notice type={message.type}>{message.text}</Notice>}
      {loading && !data && <Loading label="Loading your training…" />}
      {error && <ErrorMessage message={error} onRetry={reload} />}
      {data && data.length === 0 && <Empty>No training assigned yet.</Empty>}
      {data && data.length > 0 && (
        <ul className="rows">
          {data.map((a) => (
            <li key={a.id} className="row">
              <div>
                <h2>{a.activity.title}</h2>
                <p className="meta">{a.activity.topic} · {a.activity.plannedHours} hours</p>
              </div>
              <StatusBadge status={a.status} />
              <div className="field">
                <label htmlFor={`status-${a.id}`}>Status for {a.activity.title}</label>
                <select id={`status-${a.id}`} value={a.status} onChange={(e) => updateStatus(a, e.target.value)}>
                  {STATUSES.map((s) => <option key={s}>{s}</option>)}
                </select>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
