import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { Empty, ErrorMessage, Loading, Notice, StatusBadge } from '../components/Feedback.jsx';
import { useLoad } from '../useLoad.js';

export default function Dashboard() {
  const { expireSession } = useAuth();
  const overview = useLoad(
    async () => {
      const [summary, activities, learners] = await Promise.all([
        api.get('/cohort-summary'),
        api.get('/activities'),
        api.get('/learners'),
      ]);
      return { summary, activities, learners };
    },
    []
  );
  const [quickLearner, setQuickLearner] = useState('');
  const [assignLearner, setAssignLearner] = useState('');
  const [assignActivity, setAssignActivity] = useState('');
  const [message, setMessage] = useState(null);
  const [tick, setTick] = useState(0);

  const learners = overview.data?.learners ?? [];
  useEffect(() => {
    if (!quickLearner && learners.length) setQuickLearner(String(learners[0].id));
  }, [learners, quickLearner]);

  const quick = useLoad(
    () => (quickLearner ? api.get(`/learners/${quickLearner}/assignments`) : Promise.resolve([])),
    [quickLearner, tick]
  );

  async function assign(e) {
    e.preventDefault();
    setMessage(null);
    try {
      await api.post('/assignments', { learnerId: Number(assignLearner), activityId: Number(assignActivity) });
      setMessage({ type: 'success', text: 'Activity assigned.' });
      overview.reload();
      setTick((t) => t + 1);
    } catch (err) {
      if (err.status === 401) return expireSession();
      setMessage({ type: 'error', text: err.message });
    }
  }

  if (overview.loading && !overview.data) return <Loading label="Loading dashboard…" />;
  if (overview.error) return <ErrorMessage message={overview.error} onRetry={overview.reload} />;

  const { summary, activities } = overview.data;
  const cohorts = [...new Set(learners.map((l) => l.cohort))].join(', ');

  return (
    <>
      <div className="page-head">
        <h1>{cohorts || 'Cohort overview'}</h1>
        <Link className="btn primary" to="/activities?new=1">+ Add activity</Link>
      </div>

      <dl className="summary" aria-label="Cohort totals">
        <div><dt>Learners</dt><dd>{summary.learnerCount}</dd></div>
        <div><dt>Assignments</dt><dd>{summary.assignmentCount}</dd></div>
        <div><dt>Completed</dt><dd>{summary.completedCount}</dd></div>
      </dl>

      <div className="two-col">
        <section aria-labelledby="act-h">
          <h2 id="act-h">Learning activities</h2>
          {activities.length === 0 ? (
            <Empty>No activities yet. Add the first one to start assigning training.</Empty>
          ) : (
            <ul className="rows">
              {activities.map((a) => (
                <li key={a.id} className="row compact">
                  <div>
                    <h3>{a.title}</h3>
                    <p className="meta">{a.topic} · {a.plannedHours} hrs</p>
                  </div>
                  <div className="actions">
                    <Link className="btn" to={`/activities?edit=${a.id}`} aria-label={`Edit ${a.title}`}>Edit</Link>
                    <button type="button" className="btn" aria-label={`Assign ${a.title}`}
                      onClick={() => { setAssignActivity(String(a.id)); document.getElementById('assign-learner')?.focus(); }}>
                      Assign
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}

          <form className="panel" onSubmit={assign} aria-labelledby="assign-h">
            <h2 id="assign-h">Assign training</h2>
            <label htmlFor="assign-activity">Activity</label>
            <select id="assign-activity" required value={assignActivity} onChange={(e) => setAssignActivity(e.target.value)}>
              <option value="">Select an activity</option>
              {activities.map((a) => <option key={a.id} value={a.id}>{a.title}</option>)}
            </select>
            <label htmlFor="assign-learner">Learner</label>
            <select id="assign-learner" required value={assignLearner} onChange={(e) => setAssignLearner(e.target.value)}>
              <option value="">Select a learner</option>
              {learners.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
            </select>
            {message && <Notice type={message.type}>{message.text}</Notice>}
            <button className="btn primary">Assign activity</button>
          </form>
        </section>

        <section aria-labelledby="quick-h" className="panel">
          <h2 id="quick-h">Quick view</h2>
          {learners.length === 0 ? (
            <Empty>No candidates yet. <Link to="/candidates">Add a candidate</Link> first.</Empty>
          ) : (
            <>
              <label htmlFor="quick-learner">Learner</label>
              <select id="quick-learner" value={quickLearner} onChange={(e) => setQuickLearner(e.target.value)}>
                {learners.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
              </select>
              {quick.loading && !quick.data && <Loading />}
              {quick.error && <ErrorMessage message={quick.error} onRetry={quick.reload} />}
              {quick.data?.length === 0 && <Empty>No training assigned yet.</Empty>}
              <ul className="rows">
                {quick.data?.map((a) => (
                  <li key={a.id} className="row compact">
                    <span>{a.activity.title}</span>
                    <StatusBadge status={a.status} />
                  </li>
                ))}
              </ul>
            </>
          )}
        </section>
      </div>
    </>
  );
}
