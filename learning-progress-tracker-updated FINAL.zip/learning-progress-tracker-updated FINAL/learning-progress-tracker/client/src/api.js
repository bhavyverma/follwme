// Thin fetch wrapper. The CSRF token lives in memory only (never in browser storage).
let csrfToken = null;

export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function request(method, path, body) {
  if (method !== 'GET' && !csrfToken) await loadCsrf();
  const res = await fetch(`/api/v1${path}`, {
    method,
    credentials: 'include',
    headers: {
      ...(body !== undefined && { 'Content-Type': 'application/json' }),
      ...(method !== 'GET' && { 'X-CSRF-Token': csrfToken }),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  }).catch(() => {
    throw new ApiError(0, 'Could not reach the server. Check your connection and try again.');
  });

  const newToken = res.headers.get('X-CSRF-Token');
  if (newToken) csrfToken = newToken;
  if (res.status === 204) return null;

  const data = await res.json().catch(() => null);
  if (!res.ok) throw new ApiError(res.status, data?.message ?? 'Something went wrong. Please try again.');
  return data;
}

export async function loadCsrf() {
  const data = await request('GET', '/auth/csrf');
  if (data && data.csrfToken) {
    csrfToken = data.csrfToken;
  }
}

export const api = {
  get: (p) => request('GET', p),
  post: (p, b = {}) => request('POST', p, b),
  put: (p, b) => request('PUT', p, b),
  patch: (p, b) => request('PATCH', p, b),
  setCsrf: (t) => {
    csrfToken = t;
  },
};
