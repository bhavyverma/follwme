export const homeFor = (user) =>
  !user
    ? '/login'
    : user.mustChangePassword
      ? '/change-password'
      : user.role === 'Coordinator'
        ? '/dashboard'
        : '/my-training';
