import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';
import Layout from './components/Layout.jsx';
import { Loading } from './components/Feedback.jsx';
import Activities from './pages/Activities.jsx';
import Candidates from './pages/Candidates.jsx';
import ChangePassword from './pages/ChangePassword.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Login from './pages/Login.jsx';
import { homeFor } from './routes.js';
import MyTraining from './pages/MyTraining.jsx';

function Protected({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.mustChangePassword) return <Navigate to="/change-password" replace />;
  if (user.role !== role) return <Navigate to={homeFor(user)} replace />;
  return children;
}

export default function App() {
  const { user, loading } = useAuth();
  if (loading) return <Loading label="Starting up…" />;

  return (
    <Layout>
      <Routes>
        <Route path="/login" element={user ? <Navigate to={homeFor(user)} replace /> : <Login />} />
        <Route path="/change-password" element={user ? <ChangePassword /> : <Navigate to="/login" replace />} />
        <Route path="/dashboard" element={<Protected role="Coordinator"><Dashboard /></Protected>} />
        <Route path="/activities" element={<Protected role="Coordinator"><Activities /></Protected>} />
        <Route path="/candidates" element={<Protected role="Coordinator"><Candidates /></Protected>} />
        <Route path="/my-training" element={<Protected role="Candidate"><MyTraining /></Protected>} />
        <Route path="*" element={<Navigate to={homeFor(user)} replace />} />
      </Routes>
    </Layout>
  );
}
