import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// In development the API runs on :4000; the proxy keeps requests same-origin so
// the SameSite session cookie and CSRF header work without CORS.
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, proxy: { '/api': 'http://localhost:4000' } },
});
