process.env.BCRYPT_ROUNDS = '4'; // fast hashing for tests

import request from 'supertest';
import { createCoordinator } from '../src/accounts.js';
import { createApp } from '../src/app.js';
import { openDb } from '../src/db.js';

export const COORDINATOR = { email: 'coordinator@example.test', password: 'Coordinator-pass-1' };

export async function makeApp({ loginLimit = 1000 } = {}) {
  const db = openDb(':memory:');
  await createCoordinator(db, COORDINATOR.email, COORDINATOR.password);
  const app = createApp({ db, sessionSecret: 'test-secret', loginLimit });
  return { app, db };
}

/** A browser-like client: keeps cookies and the CSRF token, like the React app does. */
export async function newClient(app) {
  const agent = request.agent(app);
  let token = (await agent.get('/api/v1/auth/csrf')).body.csrfToken;
  const send = (method) => (url, body) => agent[method](url).set('X-CSRF-Token', token).send(body);
  return {
    agent,
    get token() {
      return token;
    },
    get: (url) => agent.get(url),
    post: send('post'),
    put: send('put'),
    patch: send('patch'),
    async login(email, password) {
      const res = await send('post')('/api/v1/auth/login', { email, password });
      if (res.body?.csrfToken) token = res.body.csrfToken;
      return res;
    },
    async changePassword(currentPassword, newPassword) {
      const res = await send('post')('/api/v1/auth/change-password', { currentPassword, newPassword });
      if (res.headers['x-csrf-token']) token = res.headers['x-csrf-token'];
      return res;
    },
  };
}

export async function coordinatorClient(app) {
  const c = await newClient(app);
  await c.login(COORDINATOR.email, COORDINATOR.password);
  return c;
}

export async function createActivity(coord, over = {}) {
  const res = await coord.post('/api/v1/activities', {
    title: 'React Basics',
    topic: 'Frontend',
    plannedHours: 6,
    ...over,
  });
  return res.body;
}

export async function createCandidateVia(coord, over = {}) {
  const res = await coord.post('/api/v1/learners', {
    name: 'Jordan Lee',
    email: 'jordan@example.test',
    cohort: 'Frontend cohort',
    ...over,
  });
  return res.body;
}

/** Creates a candidate, logs in with the temporary password and completes first-login setup. */
export async function readyCandidate(app, coord, over = {}, password = 'My-new-password-9') {
  const candidate = await createCandidateVia(coord, over);
  const client = await newClient(app);
  await client.login(candidate.credentials.username, candidate.credentials.temporaryPassword);
  await client.changePassword(candidate.credentials.temporaryPassword, password);
  return { client, candidate, password };
}
