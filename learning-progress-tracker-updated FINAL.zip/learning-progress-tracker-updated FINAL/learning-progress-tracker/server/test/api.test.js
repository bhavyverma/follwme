import assert from 'node:assert/strict';
import { test } from 'node:test';
import {
  COORDINATOR, coordinatorClient, createActivity, createCandidateVia, makeApp, newClient, readyCandidate,
} from './helpers.js';

const GENERIC = 'Invalid email or password.';

test('activities: required-field validation, create and edit', async () => {
  const { app } = await makeApp();
  const coord = await coordinatorClient(app);

  const bad = await coord.post('/api/v1/activities', { title: '', topic: 'Frontend', plannedHours: 6 });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.message, 'Title is required.');
  const zero = await coord.post('/api/v1/activities', { title: 'X', topic: 'Y', plannedHours: 0 });
  assert.equal(zero.status, 400);
  assert.equal(zero.body.message, 'Planned hours must be greater than zero.');

  const created = await coord.post('/api/v1/activities', { title: 'React Basics', topic: 'Frontend', plannedHours: 6 });
  assert.equal(created.status, 201);
  const edited = await coord.put(`/api/v1/activities/${created.body.id}`, { title: 'React Basics 2', topic: 'Frontend', plannedHours: 7.5 });
  assert.equal(edited.status, 200);
  assert.equal(edited.body.plannedHours, 7.5);
  assert.equal((await coord.put('/api/v1/activities/9999', created.body)).status, 404);
  assert.equal((await coord.get('/api/v1/activities')).body.length, 1);
});

test('assignments: the same activity cannot be assigned twice to a learner', async () => {
  const { app } = await makeApp();
  const coord = await coordinatorClient(app);
  const activity = await createActivity(coord);
  const learner = await createCandidateVia(coord);

  const first = await coord.post('/api/v1/assignments', { learnerId: learner.id, activityId: activity.id });
  assert.equal(first.status, 201);
  assert.equal(first.body.status, 'Not Started');
  const dup = await coord.post('/api/v1/assignments', { learnerId: learner.id, activityId: activity.id });
  assert.equal(dup.status, 409);
  assert.equal(dup.body.message, 'This activity is already assigned to this learner.');
  assert.equal((await coord.post('/api/v1/assignments', { learnerId: 999, activityId: activity.id })).status, 404);
  assert.equal((await coord.post('/api/v1/assignments', { activityId: activity.id })).status, 400);
});

test('primary workflow: create candidate, hand over credentials, first login, train, summarise', async () => {
  const { app } = await makeApp();
  const coord = await coordinatorClient(app);
  const react = await createActivity(coord);
  const sql = await createActivity(coord, { title: 'SQL Foundations', topic: 'Data', plannedHours: 4 });

  const created = await coord.post('/api/v1/learners', { name: 'Jordan Lee', email: 'Jordan@Example.test', cohort: 'Frontend cohort' });
  assert.equal(created.status, 201);
  assert.match(created.headers['cache-control'], /no-store/);
  assert.equal(created.body.credentials.username, 'jordan@example.test');
  assert.ok(created.body.credentials.temporaryPassword.length >= 12);

  // duplicate email is rejected case-insensitively
  const dupEmail = await coord.post('/api/v1/learners', { name: 'Other', email: 'JORDAN@example.test', cohort: 'X' });
  assert.equal(dupEmail.status, 409);
  const missing = await coord.post('/api/v1/learners', { name: '', email: 'x@example.test', cohort: 'X' });
  assert.equal(missing.status, 400);

  const a1 = (await coord.post('/api/v1/assignments', { learnerId: created.body.id, activityId: react.id })).body;
  await coord.post('/api/v1/assignments', { learnerId: created.body.id, activityId: sql.id });

  // first login: only password change / logout are allowed
  const candidate = await newClient(app);
  const login = await candidate.login(created.body.credentials.username, created.body.credentials.temporaryPassword);
  assert.equal(login.status, 200);
  assert.equal(login.body.mustChangePassword, true);
  assert.equal(JSON.stringify(login.body).includes('$2'), false);
  assert.equal((await candidate.get('/api/v1/me/assignments')).status, 403);
  assert.equal((await candidate.patch(`/api/v1/assignments/${a1.id}/status`, { status: 'Completed' })).status, 403);

  assert.equal((await candidate.changePassword('wrong-current', 'A-brand-new-pass-1')).status, 400);
  assert.equal((await candidate.changePassword(created.body.credentials.temporaryPassword, 'short')).status, 400);
  assert.equal((await candidate.changePassword(created.body.credentials.temporaryPassword, 'A-brand-new-pass-1')).status, 204);

  const mine = await candidate.get('/api/v1/me/assignments');
  assert.equal(mine.status, 200);
  assert.deepEqual(mine.body.map((a) => a.activity.title).sort(), ['React Basics', 'SQL Foundations']);

  const updated = await candidate.patch(`/api/v1/assignments/${a1.id}/status`, { status: 'Completed' });
  assert.equal(updated.status, 200);
  assert.equal(updated.body.status, 'Completed');
  assert.equal((await candidate.patch(`/api/v1/assignments/${a1.id}/status`, { status: 'Done' })).status, 400);

  // the summary is computed from saved data
  const summary = await coord.get('/api/v1/cohort-summary');
  assert.deepEqual(summary.body, { learnerCount: 1, assignmentCount: 2, completedCount: 1 });
  const detail = await coord.get(`/api/v1/learners/${created.body.id}/assignments`);
  assert.equal(detail.body.length, 2);

  // old temporary password no longer works; the new one does
  const again = await newClient(app);
  assert.equal((await again.login(created.body.credentials.username, created.body.credentials.temporaryPassword)).status, 401);
  const ok = await again.login(created.body.credentials.username, 'A-brand-new-pass-1');
  assert.equal(ok.body.mustChangePassword, false);
});

test('login failures are generic; expired temporary credentials are rejected', async () => {
  const { app, db } = await makeApp();
  const coord = await coordinatorClient(app);
  const candidate = await createCandidateVia(coord);

  const wrongPassword = await (await newClient(app)).login(candidate.credentials.username, 'nope-nope-nope');
  const unknownUser = await (await newClient(app)).login('ghost@example.test', 'nope-nope-nope');
  assert.equal(wrongPassword.status, 401);
  assert.equal(unknownUser.status, 401);
  assert.equal(wrongPassword.body.message, GENERIC);
  assert.equal(unknownUser.body.message, GENERIC);

  db.prepare('UPDATE accounts SET temp_password_expires_at = ? WHERE email = ?').run(Date.now() - 1000, candidate.credentials.username);
  const expired = await (await newClient(app)).login(candidate.credentials.username, candidate.credentials.temporaryPassword);
  assert.equal(expired.status, 401);
  assert.equal(expired.body.message, GENERIC);
});

test('coordinator reset restores first-login flow and invalidates prior sessions', async () => {
  const { app } = await makeApp();
  const coord = await coordinatorClient(app);
  const { client, candidate } = await readyCandidate(app, coord);
  assert.equal((await client.get('/api/v1/me/assignments')).status, 200);

  const reset = await coord.post(`/api/v1/learners/${candidate.id}/reset-password`, {});
  assert.equal(reset.status, 200);
  assert.match(reset.headers['cache-control'], /no-store/);
  assert.equal((await client.get('/api/v1/me/assignments')).status, 401); // old session revoked

  const fresh = await newClient(app);
  const login = await fresh.login(candidate.credentials.username, reset.body.credentials.temporaryPassword);
  assert.equal(login.body.mustChangePassword, true);
  assert.equal((await fresh.get('/api/v1/me/assignments')).status, 403);
  assert.equal((await coord.post('/api/v1/learners/9999/reset-password', {})).status, 404);
});

test('logout invalidates the session', async () => {
  const { app } = await makeApp();
  const coord = await coordinatorClient(app);
  assert.equal((await coord.get('/api/v1/auth/me')).status, 200);
  assert.equal((await coord.post('/api/v1/auth/logout', {})).status, 204);
  assert.equal((await coord.get('/api/v1/auth/me')).status, 401);
  assert.equal((await coord.get('/api/v1/learners')).status, 401);
});

test('access control: candidates cannot use coordinator actions or other candidates’ data', async () => {
  const { app } = await makeApp();
  const coord = await coordinatorClient(app);
  const activity = await createActivity(coord);
  const a = await readyCandidate(app, coord, { email: 'a@example.test', name: 'Ada' });
  const b = await readyCandidate(app, coord, { email: 'b@example.test', name: 'Ben' });
  const asgA = (await coord.post('/api/v1/assignments', { learnerId: a.candidate.id, activityId: activity.id })).body;
  await coord.post('/api/v1/assignments', { learnerId: b.candidate.id, activityId: activity.id });

  for (const url of ['/api/v1/learners', '/api/v1/activities', '/api/v1/cohort-summary', `/api/v1/learners/${a.candidate.id}/assignments`]) {
    assert.equal((await b.client.get(url)).status, 403, url);
  }
  assert.equal((await b.client.post('/api/v1/learners', { name: 'X', email: 'x@example.test', cohort: 'Y' })).status, 403);
  assert.equal((await b.client.post('/api/v1/activities', { title: 'T', topic: 'T', plannedHours: 1 })).status, 403);
  assert.equal((await b.client.post('/api/v1/assignments', { learnerId: b.candidate.id, activityId: activity.id })).status, 403);

  // cross-candidate status update is denied and nothing changes
  const denied = await b.client.patch(`/api/v1/assignments/${asgA.id}/status`, { status: 'Completed' });
  assert.equal(denied.status, 403);
  assert.equal((await a.client.get('/api/v1/me/assignments')).body[0].status, 'Not Started');
  // a submitted learnerId in the body never establishes identity
  assert.equal((await b.client.patch(`/api/v1/assignments/${asgA.id}/status`, { status: 'Completed', learnerId: a.candidate.id })).status, 403);
  // coordinators do not update candidate progress
  assert.equal((await coord.patch(`/api/v1/assignments/${asgA.id}/status`, { status: 'Completed' })).status, 403);
  assert.equal((await b.client.patch('/api/v1/assignments/9999/status', { status: 'Completed' })).status, 404);

  // each candidate only sees their own list
  assert.equal((await b.client.get('/api/v1/me/assignments')).body.length, 1);
});

test('unauthenticated requests get 401 and state changes need a CSRF token', async () => {
  const { app } = await makeApp();
  const anon = await newClient(app);
  assert.equal((await anon.get('/api/v1/activities')).status, 401);
  assert.equal((await anon.post('/api/v1/activities', {})).status, 401);

  const coord = await coordinatorClient(app);
  const noToken = await coord.agent.post('/api/v1/activities').send({ title: 'T', topic: 'T', plannedHours: 1 });
  assert.equal(noToken.status, 403);
  assert.equal((await coord.get('/api/v1/nope')).status, 404);
});

test('login is rate limited and responses never expose password hashes', async () => {
  const { app } = await makeApp({ loginLimit: 3 });
  const client = await newClient(app);
  const statuses = [];
  for (let i = 0; i < 5; i += 1) statuses.push((await client.login(COORDINATOR.email, 'wrong-password-x')).status);
  assert.deepEqual(statuses, [401, 401, 401, 429, 429]);

  const { app: app2 } = await makeApp();
  const coord = await coordinatorClient(app2);
  await createCandidateVia(coord);
  const list = await coord.get('/api/v1/learners');
  assert.equal(/password|\$2[aby]\$/i.test(JSON.stringify(list.body)), false);
});
