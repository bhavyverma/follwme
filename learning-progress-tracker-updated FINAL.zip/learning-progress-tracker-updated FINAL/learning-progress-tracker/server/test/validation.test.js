import assert from 'node:assert/strict';
import { test } from 'node:test';
import { HttpError, parseActivity, parseCandidate } from '../src/validation.js';

const badRequest = (message) => (err) => err instanceof HttpError && err.status === 400 && err.message === message;

test('activity requires title, topic and positive planned hours', () => {
  assert.throws(() => parseActivity({ topic: 'x', plannedHours: 1 }), badRequest('Title is required.'));
  assert.throws(() => parseActivity({ title: 'x', topic: '  ', plannedHours: 1 }), badRequest('Topic is required.'));
  for (const hours of [0, -2, 'abc', null, undefined, NaN]) {
    assert.throws(
      () => parseActivity({ title: 'x', topic: 'y', plannedHours: hours }),
      badRequest('Planned hours must be greater than zero.')
    );
  }
  assert.deepEqual(parseActivity({ title: ' React ', topic: 'Frontend', plannedHours: '6' }), {
    title: 'React',
    topic: 'Frontend',
    plannedHours: 6,
  });
});

test('candidate input is validated and email is normalised', () => {
  assert.throws(() => parseCandidate({ email: 'a@b.co', cohort: 'c' }), badRequest('Name is required.'));
  assert.throws(() => parseCandidate({ name: 'A', email: 'nope', cohort: 'c' }), badRequest('Enter a valid email address.'));
  assert.equal(parseCandidate({ name: 'A', email: '  A@B.Co ', cohort: 'c' }).email, 'a@b.co');
});
