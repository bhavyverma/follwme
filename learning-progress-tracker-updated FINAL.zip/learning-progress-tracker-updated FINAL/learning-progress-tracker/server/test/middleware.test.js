import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createAuthGuards, csrfProtection } from '../src/middleware.js';

// Unit tests with the database and session mocked out.
const fakeDb = (account) => ({ prepare: () => ({ get: () => account }) });
const run = (mw, req) =>
  new Promise((resolve) => mw(req, { clearCookie() {} }, (err) => resolve(err)));

test('requireAuth rejects requests without a session account (401)', async () => {
  const { requireAuth } = createAuthGuards(fakeDb(undefined));
  const err = await run(requireAuth, { session: {} });
  assert.equal(err.status, 401);
});

test('requireAuth rejects an expired temporary-password account and destroys the session', async () => {
  let destroyed = false;
  const { requireAuth } = createAuthGuards(
    fakeDb({ id: 1, email: 'a@b.test', role: 'Candidate', must_change_password: 1, temp_password_expires_at: Date.now() - 1 })
  );
  const req = { session: { accountId: 1, destroy: (cb) => { destroyed = true; cb(); } } };
  const err = await run(requireAuth, req);
  assert.equal(err.status, 401);
  assert.equal(destroyed, true);
});

test('requirePasswordSet blocks accounts still on a temporary password (403)', async () => {
  const { requirePasswordSet } = createAuthGuards(fakeDb());
  assert.equal((await run(requirePasswordSet, { account: { mustChangePassword: true } })).status, 403);
  assert.equal(await run(requirePasswordSet, { account: { mustChangePassword: false } }), undefined);
});

test('requireRole allows only the named role (403 otherwise)', async () => {
  const { requireRole } = createAuthGuards(fakeDb());
  assert.equal(await run(requireRole('Coordinator'), { account: { role: 'Coordinator' } }), undefined);
  assert.equal((await run(requireRole('Coordinator'), { account: { role: 'Candidate' } })).status, 403);
});

test('csrfProtection requires a matching token on state-changing requests', async () => {
  const session = { csrfToken: 'abc123' };
  const mk = (method, header) => ({ method, session, get: () => header });
  assert.equal(await run(csrfProtection, mk('GET')), undefined);
  assert.equal((await run(csrfProtection, mk('POST'))).status, 403);
  assert.equal((await run(csrfProtection, mk('POST', 'wrong1'))).status, 403);
  assert.equal(await run(csrfProtection, mk('POST', 'abc123')), undefined);
});
