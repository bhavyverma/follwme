import session from 'express-session';
import { SESSION_TTL_MS } from './config.js';

/** SQLite-backed session store; keeps account_id so a coordinator reset can revoke sessions. */
export class SqliteSessionStore extends session.Store {
  constructor(db, { ttlMs = SESSION_TTL_MS } = {}) {
    super();
    this.db = db;
    this.ttlMs = ttlMs;
    this.q = {
      get: db.prepare('SELECT data, expires FROM sessions WHERE sid = ?'),
      upsert: db.prepare(
        `INSERT INTO sessions (sid, account_id, expires, data) VALUES (?, ?, ?, ?)
         ON CONFLICT(sid) DO UPDATE SET account_id = excluded.account_id,
           expires = excluded.expires, data = excluded.data`
      ),
      touch: db.prepare('UPDATE sessions SET expires = ? WHERE sid = ?'),
      del: db.prepare('DELETE FROM sessions WHERE sid = ?'),
      purge: db.prepare('DELETE FROM sessions WHERE expires <= ?'),
    };
    this.timer = setInterval(() => this.q.purge.run(Date.now()), 15 * 60 * 1000);
    this.timer.unref();
  }

  #expiry(sess) {
    return sess?.cookie?.expires ? new Date(sess.cookie.expires).getTime() : Date.now() + this.ttlMs;
  }

  get(sid, cb) {
    try {
      const row = this.q.get.get(sid);
      if (!row) return cb(null, null);
      if (row.expires <= Date.now()) {
        this.q.del.run(sid);
        return cb(null, null);
      }
      return cb(null, JSON.parse(row.data));
    } catch (err) {
      return cb(err);
    }
  }

  set(sid, sess, cb) {
    try {
      this.q.upsert.run(sid, sess.accountId ?? null, this.#expiry(sess), JSON.stringify(sess));
      cb?.(null);
    } catch (err) {
      cb?.(err);
    }
  }

  touch(sid, sess, cb) {
    try {
      this.q.touch.run(this.#expiry(sess), sid);
      cb?.(null);
    } catch (err) {
      cb?.(err);
    }
  }

  destroy(sid, cb) {
    try {
      this.q.del.run(sid);
      cb?.(null);
    } catch (err) {
      cb?.(err);
    }
  }
}
