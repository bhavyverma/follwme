export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const normalizeEmail = (value) => String(value ?? '').trim().toLowerCase();

function requiredText(value, label, max) {
  const text = typeof value === 'string' ? value.trim() : '';
  if (!text) throw new HttpError(400, `${label} is required.`);
  if (text.length > max) throw new HttpError(400, `${label} must be ${max} characters or fewer.`);
  return text;
}

export function parseActivity(body = {}) {
  const title = requiredText(body.title, 'Title', 100);
  const topic = requiredText(body.topic, 'Topic', 60);
  const raw = body.plannedHours;
  const hours = typeof raw === 'string' && raw.trim() !== '' ? Number(raw) : raw;
  if (typeof hours !== 'number' || !Number.isFinite(hours) || hours <= 0 || hours > 1000) {
    throw new HttpError(400, 'Planned hours must be greater than zero.');
  }
  return { title, topic, plannedHours: hours };
}

export function parseCandidate(body = {}) {
  const name = requiredText(body.name, 'Name', 80);
  const cohort = requiredText(body.cohort, 'Cohort', 60);
  const email = normalizeEmail(body.email);
  if (!email) throw new HttpError(400, 'Email is required.');
  if (email.length > 254 || !EMAIL_RE.test(email)) {
    throw new HttpError(400, 'Enter a valid email address.');
  }
  return { name, cohort, email };
}

export function parseId(value, label = 'id') {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw new HttpError(400, `Invalid ${label}.`);
  return n;
}

export function validateNewPassword(password) {
  if (typeof password !== 'string' || password.length < 10) {
    throw new HttpError(400, 'New password must be at least 10 characters.');
  }
  if (password.length > 72) throw new HttpError(400, 'New password must be 72 characters or fewer.');
}
