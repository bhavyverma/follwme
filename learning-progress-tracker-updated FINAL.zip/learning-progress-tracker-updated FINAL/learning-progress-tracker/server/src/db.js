import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

export const STATUSES = ['Not Started', 'In Progress', 'Completed'];

const SCHEMA = `
CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('Coordinator', 'Candidate')),
  must_change_password INTEGER NOT NULL DEFAULT 0 CHECK (must_change_password IN (0, 1)),
  temp_password_expires_at INTEGER
);

CREATE TABLE IF NOT EXISTS learners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  cohort TEXT NOT NULL,
  account_id INTEGER NOT NULL UNIQUE REFERENCES accounts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS activities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  topic TEXT NOT NULL,
  planned_hours REAL NOT NULL CHECK (planned_hours > 0)
);

CREATE TABLE IF NOT EXISTS assignments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  learner_id INTEGER NOT NULL REFERENCES learners(id) ON DELETE CASCADE,
  activity_id INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'Not Started'
    CHECK (status IN ('Not Started', 'In Progress', 'Completed')),
  UNIQUE (learner_id, activity_id)
);

CREATE TABLE IF NOT EXISTS sessions (
  sid TEXT PRIMARY KEY,
  account_id INTEGER,
  expires INTEGER NOT NULL,
  data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_account ON sessions(account_id);
`;

export function openDb(path = ':memory:') {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new Database(path);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  return db;
}

export const isUniqueViolation = (err) => err?.code === 'SQLITE_CONSTRAINT_UNIQUE';

export const toActivity = (r) => ({
  id: r.id,
  title: r.title,
  topic: r.topic,
  plannedHours: r.planned_hours,
});

const ASSIGNMENT_SELECT = `
  SELECT a.id, a.learner_id, a.activity_id, a.status,
         act.title, act.topic, act.planned_hours
    FROM assignments a JOIN activities act ON act.id = a.activity_id`;

function toAssignment(r) {
  return {
    id: r.id,
    learnerId: r.learner_id,
    activityId: r.activity_id,
    status: r.status,
    activity: { id: r.activity_id, title: r.title, topic: r.topic, plannedHours: r.planned_hours },
  };
}

export function assignmentsForLearner(db, learnerId) {
  return db
    .prepare(`${ASSIGNMENT_SELECT} WHERE a.learner_id = ? ORDER BY act.title`)
    .all(learnerId)
    .map(toAssignment);
}

export function assignmentById(db, id) {
  const r = db.prepare(`${ASSIGNMENT_SELECT} WHERE a.id = ?`).get(id);
  return r ? toAssignment(r) : null;
}
