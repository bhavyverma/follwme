import { randomBytes, timingSafeEqual } from 'node:crypto';
import { SESSION_COOKIE } from './config.js';
import { HttpError } from './validation.js';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

export function ensureCsrfToken(req) {
  req.session.csrfToken ??= randomBytes(32).toString('hex');
  return req.session.csrfToken;
}

/** Synchronizer-token CSRF check for state-changing requests (token kept in the server session). */
export function csrfProtection(req, _res, next) {
  if (SAFE_METHODS.has(req.method)) return next();
  const expected = req.session?.csrfToken;
  const received = req.get('x-csrf-token');
  const ok =
    typeof expected === 'string' &&
    typeof received === 'string' &&
    expected.length === received.length &&
    timingSafeEqual(Buffer.from(expected), Buffer.from(received));
  return ok ? next() : next(new HttpError(403, 'Invalid or missing CSRF token.'));
}

/**
 * Authentication/authorization guards. The account is always re-read from the database,
 * so role and password-setup state are never trusted from the client.
 */
export function createAuthGuards(db) {
  const findAccount = db.prepare(
    'SELECT id, email, role, must_change_password, temp_password_expires_at FROM accounts WHERE id = ?'
  );

  function requireAuth(req, res, next) {
    const accountId = req.session?.accountId;
    if (!accountId) return next(new HttpError(401, 'Authentication required.'));

    const acct = findAccount.get(accountId);
    const tempExpired = acct?.must_change_password && acct.temp_password_expires_at <= Date.now();
    if (!acct || tempExpired) {
      return req.session.destroy(() => {
        res.clearCookie(SESSION_COOKIE);
        next(new HttpError(401, 'Authentication required.'));
      });
    }
    req.account = {
      id: acct.id,
      email: acct.email,
      role: acct.role,
      mustChangePassword: Boolean(acct.must_change_password),
    };
    return next();
  }

  function requirePasswordSet(req, _res, next) {
    return req.account.mustChangePassword
      ? next(new HttpError(403, 'You must change your temporary password first.'))
      : next();
  }

  const requireRole = (role) => (req, _res, next) =>
    req.account.role === role
      ? next()
      : next(new HttpError(403, 'You do not have permission to perform this action.'));

  return { requireAuth, requirePasswordSet, requireRole };
}

export function errorHandler(err, _req, res, next) {
  if (res.headersSent) return next(err);
  if (err instanceof HttpError) return res.status(err.status).json({ message: err.message });
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Request body must be valid JSON.' });
  }
  if (err.type === 'entity.too.large') return res.status(413).json({ message: 'Request body is too large.' });
  console.error('Unhandled error:', err.message); // never log request bodies (may hold passwords)
  return res.status(500).json({ message: 'Something went wrong. Please try again.' });
}
