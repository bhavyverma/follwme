import { resolve } from 'node:path';
import { createApp } from './app.js';
import { config } from './config.js';
import { openDb } from './db.js';

const db = openDb(config.databasePath);
const app = createApp({
  db,
  sessionSecret: config.sessionSecret,
  secureCookies: config.secureCookies,
  trustProxy: config.trustProxy,
  clientDist: resolve(import.meta.dirname, '../../client/dist'),
});

app.listen(config.port, () => {
  console.log(`Learning Progress Tracker API listening on http://localhost:${config.port}`);
});
