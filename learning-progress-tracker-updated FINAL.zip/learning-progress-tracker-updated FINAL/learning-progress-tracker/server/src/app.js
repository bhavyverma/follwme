import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { SESSION_COOKIE, SESSION_TTL_MS } from './config.js';
import { createAuthGuards, csrfProtection, errorHandler } from './middleware.js';
import { SqliteSessionStore } from './sessionStore.js';
import { activitiesRouter } from './routes/activities.js';
import { assignmentsRouter } from './routes/assignments.js';
import { authRouter } from './routes/auth.js';
import { learnersRouter } from './routes/learners.js';
import { meRouter, summaryRouter } from './routes/summary.js';

export function createApp({
  db,
  sessionSecret,
  secureCookies = false,
  trustProxy = false,
  loginLimit = 10,
  clientDist,
}) {
  const app = express();
  app.disable('x-powered-by');
  if (trustProxy) app.set('trust proxy', 1);

  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: { 'upgrade-insecure-requests': secureCookies ? [] : null },
      },
    })
  );
  app.use(express.json({ limit: '10kb' }));

  const cookie = { httpOnly: true, sameSite: 'lax', secure: secureCookies, maxAge: SESSION_TTL_MS };
  app.use(
    session({
      name: SESSION_COOKIE,
      secret: sessionSecret,
      store: new SqliteSessionStore(db),
      resave: false,
      saveUninitialized: false,
      rolling: true, // idle timeout
      cookie,
    })
  );

  const guards = createAuthGuards(db);
  const { requireAuth, requirePasswordSet, requireRole } = guards;
  const afterSetup = [requireAuth, requirePasswordSet, csrfProtection];
  const coordinatorOnly = [...afterSetup, requireRole('Coordinator')];

  const api = express.Router();
  api.use('/auth', authRouter(db, guards, { loginLimit, cookieOptions: { httpOnly: true, sameSite: 'lax', secure: secureCookies } }));
  api.use('/activities', coordinatorOnly, activitiesRouter(db));
  api.use('/learners', coordinatorOnly, learnersRouter(db));
  api.use('/cohort-summary', coordinatorOnly, summaryRouter(db));
  api.use('/assignments', afterSetup, assignmentsRouter(db, guards));
  api.use('/me', requireAuth, requirePasswordSet, requireRole('Candidate'), meRouter(db));
  api.use((_req, res) => res.status(404).json({ message: 'Not found.' }));
  app.use('/api/v1', api);
  app.use('/api', (_req, res) => res.status(404).json({ message: 'Not found.' }));

  if (clientDist && existsSync(join(clientDist, 'index.html'))) {
    app.use(express.static(clientDist));
    app.use((req, res, next) =>
      req.method === 'GET' ? res.sendFile(join(clientDist, 'index.html')) : next()
    );
  }

  app.use(errorHandler);
  return app;
}
