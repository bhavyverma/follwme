import 'dotenv/config';
import { randomBytes } from 'node:crypto';

const isProd = process.env.NODE_ENV === 'production';

let sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret) {
  if (isProd) throw new Error('SESSION_SECRET is required in production.');
  sessionSecret = randomBytes(48).toString('hex');
  console.warn('SESSION_SECRET not set: using a temporary secret (sessions reset on restart).');
}

export const config = {
  isProd,
  port: Number(process.env.PORT) || 4000,
  databasePath: process.env.DATABASE_PATH || './data/tracker.sqlite',
  sessionSecret,
  secureCookies: process.env.COOKIE_SECURE === 'true',
  trustProxy: process.env.TRUST_PROXY === 'true',
};

export const SESSION_COOKIE = 'lpt.sid';
export const SESSION_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours idle expiry
export const TEMP_PASSWORD_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
