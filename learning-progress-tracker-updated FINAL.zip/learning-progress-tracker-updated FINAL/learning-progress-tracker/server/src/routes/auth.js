import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { SESSION_COOKIE } from '../config.js';
import { csrfProtection, ensureCsrfToken } from '../middleware.js';
import { hashPassword, verifyPassword } from '../passwords.js';
import { HttpError, normalizeEmail, validateNewPassword } from '../validation.js';

const regenerate = (req) =>
  new Promise((resolve, reject) => req.session.regenerate((e) => (e ? reject(e) : resolve())));
const save = (req) => new Promise((resolve, reject) => req.session.save((e) => (e ? reject(e) : resolve())));

export function authRouter(db, { requireAuth }, { loginLimit = 10, cookieOptions }) {
  const router = Router();
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: loginLimit,
    standardHeaders: true,
    legacyHeaders: false,
    message: { message: 'Too many sign-in attempts. Try again in a few minutes.' },
  });

  const profile = (accountId) =>
    db
      .prepare(
        `SELECT a.role, a.email, a.must_change_password AS mustChange,
                l.id AS learnerId, l.name, l.cohort
           FROM accounts a LEFT JOIN learners l ON l.account_id = a.id WHERE a.id = ?`
      )
      .get(accountId);

  const publicUser = (p) => ({
    role: p.role,
    email: p.email,
    name: p.name ?? null,
    cohort: p.cohort ?? null,
    learnerId: p.learnerId ?? null,
    mustChangePassword: Boolean(p.mustChange),
  });

  router.get('/csrf', (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json({ csrfToken: ensureCsrfToken(req) });
  });

  router.get('/me', requireAuth, (req, res) => {
    res.set('Cache-Control', 'no-store');
    res.json(publicUser(profile(req.account.id)));
  });

  router.post('/login', loginLimiter, csrfProtection, async (req, res) => {
    const email = normalizeEmail(req.body?.email);
    const password = req.body?.password;
    if (!email || typeof password !== 'string' || !password) {
      throw new HttpError(400, 'Email and password are required.');
    }
    const acct = db.prepare('SELECT * FROM accounts WHERE email = ?').get(email);
    const passwordOk = await verifyPassword(password, acct?.password_hash);
    const tempExpired = acct?.must_change_password && acct.temp_password_expires_at <= Date.now();
    if (!acct || !passwordOk || tempExpired) {
      throw new HttpError(401, 'Invalid email or password.'); // generic: no account hints
    }

    await regenerate(req); // new session id on privilege change (prevents fixation)
    req.session.accountId = acct.id;
    const csrfToken = ensureCsrfToken(req);
    await save(req);
    res.set('Cache-Control', 'no-store');
    res.json({ ...publicUser(profile(acct.id)), csrfToken });
  });

  router.post('/change-password', requireAuth, csrfProtection, async (req, res) => {
    const { currentPassword, newPassword } = req.body ?? {};
    if (typeof currentPassword !== 'string' || !currentPassword) {
      throw new HttpError(400, 'Current password is required.');
    }
    validateNewPassword(newPassword);
    if (newPassword === currentPassword) {
      throw new HttpError(400, 'New password must be different from the current password.');
    }
    const { password_hash: hash } = db.prepare('SELECT password_hash FROM accounts WHERE id = ?').get(req.account.id);
    if (!(await verifyPassword(currentPassword, hash))) {
      throw new HttpError(400, 'Current password is incorrect.');
    }

    const newHash = await hashPassword(newPassword);
    db.prepare(
      'UPDATE accounts SET password_hash = ?, must_change_password = 0, temp_password_expires_at = NULL WHERE id = ?'
    ).run(newHash, req.account.id);

    const accountId = req.account.id;
    await regenerate(req); // rotate session
    req.session.accountId = accountId;
    const csrfToken = ensureCsrfToken(req);
    await save(req);
    db.prepare('DELETE FROM sessions WHERE account_id = ? AND sid <> ?').run(accountId, req.sessionID);

    res.set('X-CSRF-Token', csrfToken); // new token for the rotated session
    res.status(204).end();
  });

  router.post('/logout', requireAuth, csrfProtection, (req, res, next) => {
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie(SESSION_COOKIE, cookieOptions);
      return res.status(204).end();
    });
  });

  return router;
}
