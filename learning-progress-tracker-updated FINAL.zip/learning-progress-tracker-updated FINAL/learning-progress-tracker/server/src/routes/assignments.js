import { Router } from 'express';
import { STATUSES, assignmentById, isUniqueViolation } from '../db.js';
import { HttpError, parseId } from '../validation.js';

const DUPLICATE = 'This activity is already assigned to this learner.';

export function assignmentsRouter(db, { requireRole }) {
  const router = Router();

  // Coordinator-only (the role check is applied in app.js for this route group via requireRole).
  router.post('/', requireRole('Coordinator'), (req, res) => {
    const learnerId = parseId(req.body?.learnerId, 'learner');
    const activityId = parseId(req.body?.activityId, 'activity');
    if (!db.prepare('SELECT 1 FROM learners WHERE id = ?').get(learnerId)) {
      throw new HttpError(404, 'Learner not found.');
    }
    if (!db.prepare('SELECT 1 FROM activities WHERE id = ?').get(activityId)) {
      throw new HttpError(404, 'Activity not found.');
    }
    if (db.prepare('SELECT 1 FROM assignments WHERE learner_id = ? AND activity_id = ?').get(learnerId, activityId)) {
      throw new HttpError(409, DUPLICATE);
    }
    try {
      const info = db
        .prepare('INSERT INTO assignments (learner_id, activity_id) VALUES (?, ?)')
        .run(learnerId, activityId);
      res.status(201).json(assignmentById(db, Number(info.lastInsertRowid)));
    } catch (err) {
      if (isUniqueViolation(err)) throw new HttpError(409, DUPLICATE); // concurrent duplicate
      throw err;
    }
  });

  // Candidates only, and only for their own assignments. Identity comes from the session.
  router.patch('/:id/status', requireRole('Candidate'), (req, res) => {
    const id = parseId(req.params.id);
    const row = db
      .prepare(
        `SELECT l.account_id FROM assignments a JOIN learners l ON l.id = a.learner_id WHERE a.id = ?`
      )
      .get(id);
    if (!row) throw new HttpError(404, 'Assignment not found.');
    if (row.account_id !== req.account.id) {
      throw new HttpError(403, 'You do not have permission to perform this action.');
    }
    const status = req.body?.status;
    if (!STATUSES.includes(status)) {
      throw new HttpError(400, `Status must be one of: ${STATUSES.join(', ')}.`);
    }
    db.prepare('UPDATE assignments SET status = ? WHERE id = ?').run(status, id);
    res.json(assignmentById(db, id));
  });

  return router;
}
