import { Router } from 'express';
import { createCandidate, resetTemporaryPassword } from '../accounts.js';
import { assignmentsForLearner } from '../db.js';
import { HttpError, parseCandidate, parseId } from '../validation.js';

export function learnersRouter(db) {
  const router = Router();

  router.get('/', (_req, res) => {
    const rows = db
      .prepare(
        `SELECT l.id, l.name, l.cohort, a.email,
                (SELECT COUNT(*) FROM assignments WHERE learner_id = l.id) AS assignmentCount,
                (SELECT COUNT(*) FROM assignments WHERE learner_id = l.id AND status = 'Completed') AS completedCount
           FROM learners l JOIN accounts a ON a.id = l.account_id ORDER BY l.name`
      )
      .all();
    res.json(rows);
  });

  router.post('/', async (req, res) => {
    const candidate = await createCandidate(db, parseCandidate(req.body));
    res.set('Cache-Control', 'no-store'); // one-time credentials must never be cached
    res.status(201).json(candidate);
  });

  router.post('/:id/reset-password', async (req, res) => {
    const learnerId = parseId(req.params.id);
    const credentials = await resetTemporaryPassword(db, learnerId);
    res.set('Cache-Control', 'no-store');
    res.json({ learnerId, credentials });
  });

  router.get('/:id/assignments', (req, res) => {
    const id = parseId(req.params.id);
    if (!db.prepare('SELECT 1 FROM learners WHERE id = ?').get(id)) {
      throw new HttpError(404, 'Learner not found.');
    }
    res.json(assignmentsForLearner(db, id));
  });

  return router;
}
