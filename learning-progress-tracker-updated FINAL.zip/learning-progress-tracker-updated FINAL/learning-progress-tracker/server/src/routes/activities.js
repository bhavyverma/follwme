import { Router } from 'express';
import { toActivity } from '../db.js';
import { HttpError, parseActivity, parseId } from '../validation.js';

export function activitiesRouter(db) {
  const router = Router();

  router.get('/', (_req, res) => {
    res.json(db.prepare('SELECT * FROM activities ORDER BY title').all().map(toActivity));
  });

  router.post('/', (req, res) => {
    const { title, topic, plannedHours } = parseActivity(req.body);
    const info = db
      .prepare('INSERT INTO activities (title, topic, planned_hours) VALUES (?, ?, ?)')
      .run(title, topic, plannedHours);
    res.status(201).json({ id: Number(info.lastInsertRowid), title, topic, plannedHours });
  });

  router.put('/:id', (req, res) => {
    const id = parseId(req.params.id);
    const { title, topic, plannedHours } = parseActivity(req.body);
    const info = db
      .prepare('UPDATE activities SET title = ?, topic = ?, planned_hours = ? WHERE id = ?')
      .run(title, topic, plannedHours, id);
    if (info.changes === 0) throw new HttpError(404, 'Activity not found.');
    res.json({ id, title, topic, plannedHours });
  });

  return router;
}
