import { Router } from 'express';
import { assignmentsForLearner } from '../db.js';

export function summaryRouter(db) {
  const router = Router();
  router.get('/', (_req, res) => {
    // Always calculated from saved data.
    res.json(
      db
        .prepare(
          `SELECT (SELECT COUNT(*) FROM learners) AS learnerCount,
                  (SELECT COUNT(*) FROM assignments) AS assignmentCount,
                  (SELECT COUNT(*) FROM assignments WHERE status = 'Completed') AS completedCount`
        )
        .get()
    );
  });
  return router;
}

export function meRouter(db) {
  const router = Router();
  router.get('/assignments', (req, res) => {
    const learner = db.prepare('SELECT id FROM learners WHERE account_id = ?').get(req.account.id);
    res.set('Cache-Control', 'no-store');
    res.json(learner ? assignmentsForLearner(db, learner.id) : []);
  });
  return router;
}
