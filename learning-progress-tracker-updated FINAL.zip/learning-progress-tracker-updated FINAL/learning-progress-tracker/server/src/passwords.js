import bcrypt from 'bcryptjs';
import { randomInt } from 'node:crypto';

// Salted bcrypt hashes only. Rounds are configurable so tests can run fast.
const rounds = () => Number(process.env.BCRYPT_ROUNDS) || 12;

export const hashPassword = (plain) => bcrypt.hash(plain, rounds());

let dummyHash;
/** When the account is unknown, compare against a dummy hash to keep timing similar. */
export async function verifyPassword(plain, hash) {
  if (!hash) {
    dummyHash ??= await bcrypt.hash('not-a-real-password', rounds());
    await bcrypt.compare(plain, dummyHash);
    return false;
  }
  return bcrypt.compare(plain, hash);
}

// No look-alike characters (0/O, 1/l/I) to make private handover easier.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';

export function generateTemporaryPassword(length = 14) {
  let out = '';
  for (let i = 0; i < length; i += 1) out += ALPHABET[randomInt(ALPHABET.length)];
  return out;
}
