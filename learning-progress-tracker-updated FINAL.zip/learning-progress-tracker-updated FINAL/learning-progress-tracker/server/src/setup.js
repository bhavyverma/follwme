// Usage: node src/setup.js [--sample-data]
// Provisions the first coordinator from COORDINATOR_EMAIL / COORDINATOR_PASSWORD
// (no public registration, nothing hard-coded). --sample-data adds fictional demo data.
import { createCandidate, createCoordinator } from './accounts.js';
import { config } from './config.js';
import { openDb } from './db.js';
import { normalizeEmail } from './validation.js';

const db = openDb(config.databasePath);
const withSample = process.argv.includes('--sample-data');

const email = normalizeEmail(process.env.COORDINATOR_EMAIL);
const password = process.env.COORDINATOR_PASSWORD ?? '';
const hasCoordinator = db.prepare("SELECT 1 FROM accounts WHERE role = 'Coordinator'").get();

if (!hasCoordinator) {
  if (!email || password.length < 12) {
    console.error('Set COORDINATOR_EMAIL and COORDINATOR_PASSWORD (min 12 characters) in server/.env, then re-run.');
    process.exit(1);
  }
  await createCoordinator(db, email, password);
  console.log(`Coordinator account created for ${email}.`);
} else {
  console.log('A coordinator already exists; skipping coordinator creation.');
}

if (withSample) {
  if (db.prepare('SELECT 1 FROM activities LIMIT 1').get() || db.prepare('SELECT 1 FROM learners LIMIT 1').get()) {
    console.log('Data already present; skipping sample data.');
  } else {
    const activities = [
      ['React Basics', 'Frontend', 6],
      ['REST APIs', 'Backend', 8],
      ['SQL Foundations', 'Data', 4],
      ['Git Essentials', 'Tooling', 3],
    ];
    const insertActivity = db.prepare('INSERT INTO activities (title, topic, planned_hours) VALUES (?, ?, ?)');
    activities.forEach((a) => insertActivity.run(...a));

    // Seeded candidates get an already-expired random password: nothing is printed or logged.
    // The coordinator issues real temporary credentials with "Reset credentials" in the UI.
    const people = [
      { name: 'Jordan Lee', email: 'jordan.lee@example.test', cohort: 'Frontend cohort' },
      { name: 'Priya Raman', email: 'priya.raman@example.test', cohort: 'Frontend cohort' },
      { name: 'Samir Costa', email: 'samir.costa@example.test', cohort: 'Frontend cohort' },
    ];
    const ids = [];
    for (const p of people) ids.push((await createCandidate(db, p, { expireNow: true })).id);

    const insertAssignment = db.prepare('INSERT INTO assignments (learner_id, activity_id, status) VALUES (?, ?, ?)');
    [
      [0, 1, 'In Progress'],
      [0, 2, 'Completed'],
      [0, 3, 'Not Started'],
      [1, 1, 'Completed'],
      [1, 2, 'In Progress'],
      [2, 1, 'Not Started'],
      [2, 4, 'Completed'],
      [2, 3, 'Completed'],
    ].forEach(([l, a, s]) => insertAssignment.run(ids[l], a, s));
    console.log('Sample data added: 3 learners, 4 activities, 8 assignments.');
    console.log('Sign in as the coordinator and use "Reset credentials" to hand over candidate logins.');
  }
}
db.close();
