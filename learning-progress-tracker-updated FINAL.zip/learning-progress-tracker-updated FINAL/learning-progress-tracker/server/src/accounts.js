import { TEMP_PASSWORD_TTL_MS } from './config.js';
import { isUniqueViolation } from './db.js';
import { generateTemporaryPassword, hashPassword } from './passwords.js';
import { HttpError, normalizeEmail } from './validation.js';

const credentials = (email, temporaryPassword, expiresAt) => ({
  username: email,
  temporaryPassword,
  expiresAt: new Date(expiresAt).toISOString(),
});

export async function createCoordinator(db, email, password) {
  const hash = await hashPassword(password);
  db.prepare(
    `INSERT INTO accounts (email, password_hash, role, must_change_password)
     VALUES (?, ?, 'Coordinator', 0)`
  ).run(normalizeEmail(email), hash);
}

/** Creates the account + learner and returns one-time credentials. Throws 409 on duplicate email. */
export async function createCandidate(db, { name, email, cohort }, { expireNow = false } = {}) {
  const temporaryPassword = generateTemporaryPassword();
  const hash = await hashPassword(temporaryPassword);
  const expiresAt = expireNow ? Date.now() : Date.now() + TEMP_PASSWORD_TTL_MS;
  try {
    const learnerId = db.transaction(() => {
      const acct = db
        .prepare(
          `INSERT INTO accounts (email, password_hash, role, must_change_password, temp_password_expires_at)
           VALUES (?, ?, 'Candidate', 1, ?)`
        )
        .run(email, hash, expiresAt);
      const learner = db
        .prepare('INSERT INTO learners (name, cohort, account_id) VALUES (?, ?, ?)')
        .run(name, cohort, acct.lastInsertRowid);
      return Number(learner.lastInsertRowid);
    })();
    return { id: learnerId, name, email, cohort, credentials: credentials(email, temporaryPassword, expiresAt) };
  } catch (err) {
    if (isUniqueViolation(err)) throw new HttpError(409, 'A candidate with this email already exists.');
    throw err;
  }
}

/** New temporary password, forces first-login flow, invalidates all prior sessions. */
export async function resetTemporaryPassword(db, learnerId) {
  const learner = db
    .prepare('SELECT l.account_id, a.email FROM learners l JOIN accounts a ON a.id = l.account_id WHERE l.id = ?')
    .get(learnerId);
  if (!learner) throw new HttpError(404, 'Candidate not found.');

  const temporaryPassword = generateTemporaryPassword();
  const hash = await hashPassword(temporaryPassword);
  const expiresAt = Date.now() + TEMP_PASSWORD_TTL_MS;
  db.transaction(() => {
    db.prepare(
      'UPDATE accounts SET password_hash = ?, must_change_password = 1, temp_password_expires_at = ? WHERE id = ?'
    ).run(hash, expiresAt, learner.account_id);
    db.prepare('DELETE FROM sessions WHERE account_id = ?').run(learner.account_id);
  })();
  return credentials(learner.email, temporaryPassword, expiresAt);
}
